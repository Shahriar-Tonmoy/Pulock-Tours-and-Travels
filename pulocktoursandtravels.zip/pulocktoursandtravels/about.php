<?php include "header.php"; ?>
<div class="page-top" id="templatemo_about">
        </div>
        <div class="middle-content">
            <div class="container">
                <div class="row">
                    <h2 class="page-head">About Us</h2>
                </div>
                <div class="row"><!-- first row -->
                
                	<div class="col-md-6"><!-- first column -->
                        <div class="widget-item">
                            <!--<h3 class="widget-title">Our Company</h3>-->
                            <div class="sample-thumb">
                                <img src="images/about_1.jpg" alt="about us" title="about us">
                            </div> <!-- /.sample-thumb -->
                            <h4 class="consult-title"></h4>
                            <p>Pulock Tours & Travels Provides its all members exclusive offers and One-of-a-Kind experiences Personally Reviewed by Our Deal experts around the Globe.Flight Local is a Rapidly growing  Company  Who Dominates the online Travel and Tourism Trade.We Provide a Complete Travel Solution For Your Business. Our motto is to Establish Globalized amenities for every Travel Company that Wishes to expand its Business From Ground to Web. it is an enriched Platform Where we ensure Services Compared to international quality.We have Successfully entrenched Our Service  as an authentic and adaptable brand in the Digital Aura of Technology Worldwide. We work in partnership with more than 8,000 top Travel suppliers -Our Long-Standing Relationships Give Pulock Tours & Travels all member's access to irresistible Deals.<br><br>
							While it does cost companies money to have their deals listed on Pulock Tours & Travels, no amount of money ensures that a deal will get Listed.
                            <br><br>
                            We offer prompt Visa Service, Varieties of Ticketing operations, Multiple Lists For Short and Long Holiday plans,Group tour packages, endless Hotel Lists as per requirement and what not.
                        </p>
                        </div> <!-- /.widget-item -->
                    </div> <!-- /.col-md-4 -->

                    <div class="col-md-6"><!-- second column -->
                        <div class="widget-item">
                            <!--<h3 class="widget-title">Our Team</h3>-->
                            <div class="sample-thumb">
                                <img src="images/about_2.jpg" alt="company" title="company">
                            </div> <!-- /.sample-thumb -->
                            <h4 class="consult-title"></h4>
                            <p>By Connecting with Flight Local,you will acquire attractive yet affordable Fares, Custom-Built Search options,Hassle-Free Booking Facilities,etc.We are Committed to Work Restlessly for the Growth of OTA in Our Country Bangladesh.
                            <br><br>
                            Pulock Tours & Travels (PTT) is Proud to provide one of the best education and Visa related services in Bangladesh. We always Working Closely with our beloved Students and Clients to Fulfill their Dreams with a Professional, Fast and Cost effective manner.
                            <br><br>
                            Pulock Tours & Travels pursue to retain the experiences, Skills and Vibrant  Teams in the Field of CAA, Aviation Industry. Travel industry to achieve the objectives of Digital Bangladesh Promoting the best Practices of industry and regulations. We're passionate to innovative, improve and making Complex things easier. Connecting the dreams  into ideas and transforming  objectives into tasks with technology generating revenue returns is Our excellence.
                        </p>
                        </div> <!-- /.widget-item -->
                    </div> <!-- /.col-md-4 -->
                    
                    
                    
                </div> <!-- /.row first -->
                
                
                
            </div> <!-- /.container -->
        </div> <!-- /.middle-content -->

<?php include "footer.php"; ?>